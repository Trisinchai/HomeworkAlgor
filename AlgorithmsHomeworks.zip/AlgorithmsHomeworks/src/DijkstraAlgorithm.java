import java.util.ArrayList;

public class DijkstraAlgorithm {

    private int size;
    private String[] vertex;
    private int[] dist;
    private String[] prev;
    private ArrayList<NodeAddress> allVertex;
    private String[] checkVertex;

    public DijkstraAlgorithm(ArrayList Node){
        this.allVertex = Node;
        this.size = allVertex.size();
        this.vertex = new String[size];
        this.dist = new int[size];
        this.prev = new String[size];
        this.checkVertex = new String[size];
        setDataDefault();
    }

    public void setDataDefault(){
        for(int i=0 ;i<size;i++){
            vertex[i] = allVertex.get(i).getNodeName();
            prev[i] = "";
            dist[i] = Integer.MAX_VALUE-1000;
            checkVertex[i] = allVertex.get(i).getNodeName();
        }

    }

    public int checkKeyDist(String S){
        int output = 0;
        for(int i=0;i<size;i++){
            if(vertex[i].equals(S)){
                output = i;
            }
        }
        //System.out.println("///////////"+output);
        return output;
    }

    public boolean checkVertex(int input){
        boolean output = true;
        if(checkVertex[input].equals("")) {
            output = false;
        }
        return output;
    }

    public int compute(int start,int end){

        setDataDefault();

        int output = 0;
        dist[start] = 0;
        int pick = 0;

        for(int i=0;i<size;i++){
            //System.out.println("------------------------- start : "+start+" end : "+end+"   "+i+"---------------------------");
            if (i==size-1){
                //System.out.println("************"+vertex[end]);
                output = dist[end];
                break;
            }

            if(i==0){
                checkVertex[start] = "";
                //System.out.println("----------------Go 1");
                for(int j=0;j<allVertex.get(start).getCountNeighbors();j++){

                    if(   (dist[start]) + (allVertex.get(start).getDistance(j))     <    dist[checkKeyDist(allVertex.get(start).getNeighbors(j))]){
                        dist[checkKeyDist(allVertex.get(start).getNeighbors(j))] = (dist[start])+(allVertex.get(start).getDistance(j));
                        prev[checkKeyDist(allVertex.get(start).getNeighbors(j))] = vertex[start];
                        //System.out.println("dist["+checkKeyDist(allVertex.get(start).getNeighbors(j))+"] = "+dist[checkKeyDist(allVertex.get(start).getNeighbors(j))]);
                    }
                }
            }
            else{
                checkVertex[pick] = "";
                //System.out.println("----------------Go 2");
                for(int j=0;j<allVertex.get(pick).getCountNeighbors();j++){
                    if((dist[pick])+(allVertex.get(pick).getDistance(j))<dist[checkKeyDist(allVertex.get(pick).getNeighbors(j))]){
                        dist[checkKeyDist(allVertex.get(pick).getNeighbors(j))] = (dist[pick])+(allVertex.get(pick).getDistance(j));
                        prev[checkKeyDist(allVertex.get(pick).getNeighbors(j))] = vertex[pick];
                        //System.out.println("dist["+checkKeyDist(allVertex.get(pick).getNeighbors(j))+"] = "+dist[checkKeyDist(allVertex.get(pick).getNeighbors(j))]);
                    }
                }
            }
            /*for(int j = 0;j<size;j++){
                if(checkVertex(j))ว
                //System.out.println("dist["+j+"] = "+dist[j]);
            }*/
            int min = Integer.MAX_VALUE-1000;
            for(int j =0;j<size;j++){
                if((dist[j] < min) && checkVertex(j)){
                    min = dist[j];
                    pick = j;
                    //System.out.println("-----pick : "+j+"   min : "+min);
                }
            }
        }
        return output;
    }

}
