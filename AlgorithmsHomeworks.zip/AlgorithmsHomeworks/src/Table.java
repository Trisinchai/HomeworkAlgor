import java.util.ArrayList;

public class Table {

    private int count;
    private int table[][];
    private int tableModified[][];
    //private DemandTimeDistance DTD ;
    private int size;
    private ArrayList<NodeAddress> Node;
    private DijkstraAlgorithm DA;
    //private MyopicMedian MM;
    private int pick = 0;
    private int minTotal = 0;
    private int core = 0;

    public Table(int[][] A , int[][] B){
        this.table = A;
        this.tableModified = B;
    }

    public Table(ArrayList Node,int core,int count){
        this.Node = Node;
        this.size = Node.size();
        this.table = new int[size+1][size];
        this.tableModified = new int[size+1][size];
        //this.DTD = new DemandTimeDistance(Node);
        this.DA = new DijkstraAlgorithm(Node);
        //this.MM = new MyopicMedian(Node,core);
        this.core = core;
        this.count = count;
    }

    public void setTableModified(int[][] tableModified){
        this.tableModified = tableModified;
    }

    public void setTable(int[][]table){
        this.table = table;
    }

    public void printTableModified(){
        for(int i=0;i<size+1;i++){
            for(int j =0;j<size;j++){
                if(tableModified[i][j]<10){
                    System.out.print("xxx"+tableModified[i][j]+" ");
                }else if(tableModified[i][j]<100){
                    System.out.print("xx"+tableModified[i][j]+" ");
                }else if(tableModified[i][j]<1000){
                    System.out.print("x"+tableModified[i][j]+" ");
                }else{
                    System.out.print(tableModified[i][j]+" ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    public void printTable(){
        for(int i=0;i<size;i++){
            for(int j =0;j<size;j++){
                if(tableModified[i][j]<10){
                System.out.print("x"+table[i][j]+" ");
                }else{
                    System.out.print(table[i][j]+" ");
                }
            }
            System.out.println();
        }
        System.out.println("\n");
    }

    public  int getCount(){
        return count;
    }

    public int[][] getTable(){
        return table;
    }

    public int[][] getTableModified(){
        return tableModified;
    }

    public int getMinTotal(){
        return minTotal;
    }

    public int getPick(){
        return pick;
    }

    public int minTotal(int[][] tableModified){
        int min = Integer.MAX_VALUE;
        int pick = 0;

        for(int i =0;i<size;i++){
            if(tableModified[size][i] < min){
                min = tableModified[size][i];
                minTotal = min;
                pick = i;
            }
        }
        return pick;
    }

    public void setTableByDijkstraAlgorithm(){
        for(int i=0;i<size;i++){
            for(int j =0;j<size;j++){
                if(i==j){
                    table[i][j] = 0;
                }else{
                    table[i][j] = DA.compute(i,j);
                }
            }
        }

        for(int i=0;i<size;i++){
            for(int j =0;j<size;j++){
                if(i==j){
                    tableModified[i][j] = 0;
                }else{
                    tableModified[i][j] = DA.compute(i,j);
                }
            }
        }

        for(int i=0;i<Node.size();i++){
            for(int j =0;j<Node.size();j++){
                tableModified[i][j] = tableModified[i][j]*Node.get(i).getValue();
            }
        }

        for(int j =0;j<Node.size();j++){
            tableModified[Node.size()][j] = 0;
        }
        for(int i=0;i<Node.size();i++){
            for(int j =0;j<Node.size();j++){
                tableModified[Node.size()][j] +=  tableModified[i][j];
            }
        }

        this.pick = minTotal(tableModified);
    }

    public void setTableByMyopicMedian(int pick){
        for(int i=0;i<size;i++){
            tableModified[pick][i] = 0;
        }
        for(int i=0 ;i<Node.size();i++){
            for(int j=0 ;j<Node.size();j++){
                if(table[i][j] >= table[i][pick]){
                    table[i][j] = table[i][pick];
                }
            }
        }

        for(int i=0;i<Node.size();i++){
            for(int j =0;j<Node.size();j++){
                tableModified[i][j] = tableModified[i][j]/Node.get(i).getValue();
            }
        }

        for(int i=0 ;i<Node.size();i++){
            for(int j=0 ;j<Node.size();j++){
                if(tableModified[i][j] >= tableModified[i][pick]){
                    tableModified[i][j] = tableModified[i][pick];
                }
            }
        }

        for(int i=0;i<Node.size();i++){
            for(int j =0;j<Node.size();j++){
                tableModified[i][j] = tableModified[i][j]*Node.get(i).getValue();
            }
        }

        for(int j =0;j<Node.size();j++){
            tableModified[Node.size()][j] = 0;
        }
        for(int i=0;i<Node.size();i++){
            for(int j =0;j<Node.size();j++){
                tableModified[Node.size()][j] +=  tableModified[i][j];
            }
        }

        this.pick = minTotal(tableModified);
    }

}
