import jdk.swing.interop.SwingInterOpUtils;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class RunProgram {

    private static ArrayList<NodeAddress> Node = new ArrayList<NodeAddress>();
    private static ArrayList<Table> table = new ArrayList<Table>();
    private static double allValue = 0;

    public static boolean checkNode(String name){
        boolean check = false;
        for(int i=0 ; i<Node.size();i++){
            if(Node.get(i).getNodeName().equals(name)){
                check = true;
                break;
            }
        }
        return check;
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        try {
            String name = "";
            int value = 0;
            while(true){

                System.out.print("Create node And value ");
                name = scan.next();

                if(name.equals("XXX")){
                    System.out.println("Create complete!!\n");
                    break;
                }

                value = scan.nextInt();


                if(checkNode(name)||value<0){
                    System.out.println("Please enter unique information!!");
                    continue;
                }else {
                    Node.add(new NodeAddress(name,value));
                    System.out.println("Complete!!");
                }

            }

//////////////////////////////////////////////////////////////////////////////////

            for(int i=0 ; i<Node.size();i++){

                System.out.print("Node : "+Node.get(i).getNodeName()+"\nSet neighbors : ");

                while(true){
                    name = scan.next();

                    if(name.equals("XXX")){
                        break;
                    }

                    value = scan.nextInt();

                    if(name.equals(Node.get(i).getNodeName())||!RunProgram.checkNode(name)||Node.get(i).checkNeighbors(name)||value<0){
                        //Check name = name -> if have will true  || Check name have in node -> if not have will true || Check name heve in neighbors if have will true
                        System.out.println("failed!!");
                        System.out.print("Plz set neighbors again : ");
                        continue;
                    }else{

                        Node.get(i).setNeighbors(name,value);
                        //Set neighbors and distance of Node.get(i)

                        for(int j=0;j<Node.size();j++){
                            if(Node.get(j).getNodeName().equals(name)){
                                Node.get(j).setNeighbors(Node.get(i).getNodeName(),value);
                                //Set neighbors and distance of name
                            }
                        }

                        System.out.println("Complete!!");
                        System.out.print("Set neighbors : ");

                    }

                }
                System.out.println();
            }

            for(int i=0 ; i<Node.size();i++){
                allValue += Node.get(i).getValue();
            }

            for(int i=0 ; i<Node.size();i++){
                System.out.println("Node : "+Node.get(i).getNodeName());
                System.out.print("Have beighbors : ");
                Node.get(i).getNeighbors();
                System.out.println();
            }

//////////////////////////////////////////////////////////////////////////////////

            System.out.println("\nPlease enter the number of core");
            int core = scan.nextInt();
            System.out.println();

//////////////////////////////////////////////////////////////////////////////////

            for(int i=0 ;i<core;i++){
                if(i==0){
                    table.add(new Table(Node,core,i));
                    table.get(i).setTableByDijkstraAlgorithm();
                    table.get(i).printTable();
                    table.get(i).printTableModified();
                    System.out.println("Core number : "+(i+1)+" Pick : "+table.get(i).getPick()+"\n__________________________________________");

                }else{
                    table.add(new Table(Node,core,i));
                    table.get(i).setTable(table.get(i-1).getTable());
                    table.get(i).setTableModified(table.get(i-1).getTableModified());
                    table.get(i).setTableByMyopicMedian(table.get(i-1).getPick());
                    table.get(i).printTable();
                    table.get(i).printTableModified();
                    System.out.println("Core number : "+(i+1)+" Pick : "+table.get(i).getPick()+"\n__________________________________________");

                }
                System.out.println("\n");
            }

            for(int i=0;i<table.size();i++){
                double averageDistance = (table.get(i).getMinTotal()/allValue);
                System.out.print("Median Number : "+(table.get(i).getCount()+1)+" | Location : "+Node.get(table.get(i).getPick()).getNodeName()+" | Total Demand-Weighted Distance : "+table.get(i).getMinTotal()+" | Average Distance : ");
                System.out.printf("%.3f\n",averageDistance);
            }

            for(int i=0;i<table.size();i++){
                table.get(i).printTable();
            }

        }
        catch (InputMismatchException e){
            System.out.println("Plz enter correct information");
        }


    }



}
