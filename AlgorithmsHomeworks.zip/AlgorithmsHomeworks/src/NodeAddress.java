import java.util.ArrayList;

public class NodeAddress {
    private String  nodeName;
    private int value;
    private ArrayList<String> neighbors = new ArrayList<>();
    private ArrayList<Integer> distance = new ArrayList<>();
    private int countNeighbors = 0;

    public NodeAddress(String name,int value){
        this.nodeName = name;
        this.value = value;
    }

    public void setNeighbors(String nameNeighbors,int valueDistance){
        neighbors.add(nameNeighbors);
        distance.add(valueDistance);
        countNeighbors++;
    }

    public void setValue(int value){
        this.value = value;
    }

    public String getNodeName(){
        return nodeName;
    }

    public int getValue(){
        return value;
    }

    public int getCountNeighbors(){
        return countNeighbors;
    }

    public int getDistance(int key){
        return distance.get(key);
    }

    public String getNeighbors(int key){
        return neighbors.get(key);
    }

    public void getNeighbors(){
        if(countNeighbors == 0){
            System.out.println("Not have neighbors!!");
        }else{
            for(int i=0; i<neighbors.size();i++){
                System.out.println(neighbors.get(i)+" = "+distance.get(i)+" ");
            }

        }
    }

    public boolean checkNeighbors(String name){
        boolean check = false;
        for(int i=0; i<neighbors.size();i++){
            if(neighbors.get(i).equals(name)){
                check = true;
                break;
            }
        }
        return check;
    }
}
