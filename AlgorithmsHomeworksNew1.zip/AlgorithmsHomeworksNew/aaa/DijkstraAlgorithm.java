import java.util.ArrayList;

public class DijkstraAlgorithm {

    private int size;
    private int[] vertex;
    private int[] dist;
    private int[] prev;
    private ArrayList<Vertex> allVertex;
    private int[] checkVertex;

    public DijkstraAlgorithm(ArrayList Node){
        this.allVertex = Node;
        this.size = allVertex.size();
        this.vertex = new int[size];
        this.dist = new int[size];
        this.prev = new int[size];
        this.checkVertex = new int[size];
        setDataDefault();
    }

    public void setDataDefault(){
        for(int i=0 ;i<size;i++){
            vertex[i] = allVertex.get(i).name;
            prev[i] = -1;
            dist[i] = Integer.MAX_VALUE-1000;
            checkVertex[i] = allVertex.get(i).name;
        }

    }

    public int checkKeyDist(int S){
        int output = 0;
        for(int i=0;i<size;i++){
            if(vertex[i] == S){
                output = i;
            }
        }
        //System.out.println("///////////"+output);
        return output;
    }

    public boolean checkVertex(int input){
        boolean output = true;
        if(checkVertex[input] == -1) {
            output = false;
        }
        return output;
    }

    public int compute(int start,int end){

        setDataDefault();

        int output = 0;
        dist[start] = 0;
        int pick = 0;
        for(int i=0;i<size;i++){
            if (i==size-1){
                output = dist[end];
                break;
            }

            if(i==0){
                checkVertex[start] = -1;
               // System.out.println("----------------Go 1");
                for(int j=0;j<allVertex.get(start).countNeighbors;j++){
                    if(   (dist[start]) + (allVertex.get(start).distance.get(j))   <  dist[checkKeyDist(allVertex.get(start).neighbors.get(j))]){
                        dist[checkKeyDist(allVertex.get(start).neighbors.get(j))] = (dist[start])+(allVertex.get(start).distance.get(j));
                        prev[checkKeyDist(allVertex.get(start).neighbors.get(j))] = vertex[start];
                    }
                }
            }

            else{
                checkVertex[pick] = -1;
                //System.out.println("----------------Go 2");
                for(int j=0;j<allVertex.get(pick).countNeighbors;j++){
                    if((dist[pick])+(allVertex.get(pick).distance.get(j))<dist[checkKeyDist(allVertex.get(pick).neighbors.get(j))]){
                        dist[checkKeyDist(allVertex.get(pick).neighbors.get(j))] = (dist[pick])+(allVertex.get(pick).distance.get(j));
                        prev[checkKeyDist(allVertex.get(pick).neighbors.get(j))] = vertex[pick];

                    }
                }
            }
            /*for(int j = 0;j<size;j++){
                if(checkVertex(j))ว
                //System.out.println("dist["+j+"] = "+dist[j]);
            }*/
            int min = Integer.MAX_VALUE-1000;
            for(int j =0;j<size;j++){
                if((dist[j] < min) && checkVertex(j)){
                    min = dist[j];
                    pick = j;
                    //System.out.println("-----pick : "+j+"   min : "+min);
                }
            }
        }
        return output;
    }

}
