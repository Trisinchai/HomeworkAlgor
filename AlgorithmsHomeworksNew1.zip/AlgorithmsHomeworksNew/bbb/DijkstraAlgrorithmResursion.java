
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author nnon_
 */
public class DijkstraAlgrorithmResursion {

    private int size;
    private int[] vertex;
    private int[] dist;
    private int[] prev;
    private ArrayList<Vertex> allVertex;
    private int[] checkVertex;

    public DijkstraAlgrorithmResursion(ArrayList Node) {
        this.allVertex = Node;
        this.size = allVertex.size();
        this.vertex = new int[size];
        this.dist = new int[size];
        this.prev = new int[size];
        this.checkVertex = new int[size];
        setDataDefault(0);
    }

    public void setDataDefault(int i) {
        int loop = i;
        if (loop >= size) {
            return;
        } else {
            vertex[loop] = allVertex.get(loop).name;
            prev[loop] = -1;
            dist[loop] = Integer.MAX_VALUE - 1000;
            checkVertex[loop] = allVertex.get(loop).name;
            setDataDefault(loop + 1);
        }
        /*for (int i = 0; i < size; i++) {
            vertex[i] = allVertex.get(i).name;
            prev[i] = -1;
            dist[i] = Integer.MAX_VALUE - 1000;
            checkVertex[i] = allVertex.get(i).name;
        }*/
    }

    public boolean checkVertex(int input) {
        boolean output = true;
        if (checkVertex[input] == -1) {
            output = false;
        }
        return output;
    }

    public int checkKeyDist(int S, int size) {
        int output = 0;
        int sizeloop = size - 1;
        /*for(int i=0;i<size;i++){
            if(vertex[i] == S){
                output = i;
            }
        }
        System.out.println("///////////"+output);*/
        if (sizeloop <= -1) {
            return output;
        } else if (vertex[sizeloop] == S) {
            output = sizeloop;
        } else {
            output = checkKeyDist(S, sizeloop);
        }

        return output;

    }

    public int compute(int start, int end) {
        
        setDataDefault(0);
        
        int output = 0;
        dist[start] = 0;
        int pick = 0;

        
        /*if (loop == 0) {
            setDataDefault(0);
        }

        if (loop == size - 1) {
            output = dist[end];
            return output;
        } else {
            if (loop == 0) {
                checkVertex[start] = -1;
                //System.out.println("----------------Go 1");
                for (int j = 0; j < allVertex.get(start).countNeighbors; j++) {
                    if ((dist[start]) + (allVertex.get(start).distance.get(j)) < dist[checkKeyDist(allVertex.get(start).neighbors.get(j), this.size)]) {
                        dist[checkKeyDist(allVertex.get(start).neighbors.get(j), this.size)] = (dist[start]) + (allVertex.get(start).distance.get(j));
                        prev[checkKeyDist(allVertex.get(start).neighbors.get(j), this.size)] = vertex[start];
                    }
                }
            } else {
                checkVertex[pick] = -1;
                //System.out.println("----------------Go 2");
                for (int j = 0; j < allVertex.get(pick).countNeighbors; j++) {
                    if ((dist[pick]) + (allVertex.get(pick).distance.get(j)) < dist[checkKeyDist(allVertex.get(pick).neighbors.get(j), this.size)]) {
                        dist[checkKeyDist(allVertex.get(pick).neighbors.get(j), this.size)] = (dist[pick]) + (allVertex.get(pick).distance.get(j));
                        prev[checkKeyDist(allVertex.get(pick).neighbors.get(j), this.size)] = vertex[pick];

                    }
                }
            }

            int min = Integer.MAX_VALUE - 1000;
            for (int j = 0; j < size; j++) {
                if ((dist[j] < min) && checkVertex(j)) {
                    min = dist[j];
                    pick = j;
                    //System.out.println("-----pick : "+j+"   min : "+min);
                }
            }
            compute(start, end, pick, loop + 1);
        }*/
        for (int i = 0; i < size; i++) {
            if (i == size - 1) {
                output = dist[end];
                break;
            }

            if (i == 0) {
                checkVertex[start] = -1;
                // System.out.println("----------------Go 1");
                for (int j = 0; j < allVertex.get(start).countNeighbors; j++) {
                    if ((dist[start]) + (allVertex.get(start).distance.get(j)) < dist[checkKeyDist(allVertex.get(start).neighbors.get(j), this.size)]) {
                        dist[checkKeyDist(allVertex.get(start).neighbors.get(j), this.size)] = (dist[start]) + (allVertex.get(start).distance.get(j));
                        prev[checkKeyDist(allVertex.get(start).neighbors.get(j), this.size)] = vertex[start];
                    }
                }
            } else {
                checkVertex[pick] = -1;
                //System.out.println("----------------Go 2");
                for (int j = 0; j < allVertex.get(pick).countNeighbors; j++) {
                    if ((dist[pick]) + (allVertex.get(pick).distance.get(j)) < dist[checkKeyDist(allVertex.get(pick).neighbors.get(j), this.size)]) {
                        dist[checkKeyDist(allVertex.get(pick).neighbors.get(j), this.size)] = (dist[pick]) + (allVertex.get(pick).distance.get(j));
                        prev[checkKeyDist(allVertex.get(pick).neighbors.get(j), this.size)] = vertex[pick];

                    }
                }
            }
            /*for(int j = 0;j<size;j++){
                if(checkVertex(j))
                //System.out.println("dist["+j+"] = "+dist[j]);
            }*/
            int min = Integer.MAX_VALUE - 1000;
            for (int j = 0; j < size; j++) {
                if ((dist[j] < min) && checkVertex(j)) {
                    min = dist[j];
                    pick = j;
                    //System.out.println("-----pick : "+j+"   min : "+min);
                }
            }
        }
        return output;
    }
}
