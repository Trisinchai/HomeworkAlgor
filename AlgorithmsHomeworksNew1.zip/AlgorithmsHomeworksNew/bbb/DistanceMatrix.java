
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class DistanceMatrix {

    static ArrayList<Vertex> V = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(System.in);
        System.out.println("Input mode 0 or 1");
        int mode = scan.nextInt();
        if (mode == 0) { //
            System.out.println("Input Vertex Number , Edges Number , Core Number");
            int vertex = scan.nextInt();
            int edges = scan.nextInt();
            int core = scan.nextInt();
            int[][] table = new int[vertex][vertex];
            int count = 0;

            for (int i = 0; i < edges; i++) {
                System.out.println("Input VertexStart , VertexEnd");
                int vertexStart = scan.nextInt();
                int vertexEnd = scan.nextInt();

                boolean c1 = false;
                boolean c2 = false;
                if (vertexStart == vertexEnd || vertexStart < 0 || vertexEnd < 0) {
                    System.out.println("Do not repeat vertexStart and vertexEnd");
                    continue;
                }
                System.out.println("Input CostEdges");
                int costEdges = scan.nextInt();
                if (count == 0) {
                    V.add(new Vertex(vertexStart, vertexEnd, costEdges));
                    V.add(new Vertex(vertexEnd, vertexStart, costEdges));
                    count += 2;
                } else {

                    for (int k = 0; k < count; k++) {
                        if (V.get(k).name == vertexStart) {
                            c1 = true;
                            break;
                        }
                    }

                    for (int k = 0; k < count; k++) {
                        if (V.get(k).name == vertexEnd) {
                            c2 = true;
                            break;
                        }
                    }

                    if (c1 == true && c2 == true) {

                        for (int k = 0; k < count; k++) {
                            boolean c3 = false;
                            if (V.get(k).name == vertexStart) {
                                for (int l = 0; l < V.get(k).neighbors.size(); l++) {
                                    if (V.get(k).neighbors.get(l) == vertexEnd) {
                                        V.get(k).distance.set(l, costEdges);
                                        c3 = true;
                                        break;
                                    }
                                }
                                if (c3 == false) {
                                    V.get(k).distance.add(costEdges);
                                    V.get(k).neighbors.add(vertexEnd);
                                    V.get(k).countNeighbors++;
                                }
                                break;
                            }
                        }

                        for (int k = 0; k < count; k++) {
                            boolean c3 = false;
                            if (V.get(k).name == vertexEnd) {
                                for (int l = 0; l < V.get(k).neighbors.size(); l++) {
                                    if (V.get(k).neighbors.get(l) == vertexStart) {
                                        V.get(k).distance.set(l, costEdges);
                                        c3 = true;
                                        break;
                                    }
                                }
                                if (c3 == false) {
                                    V.get(k).distance.add(costEdges);
                                    V.get(k).neighbors.add(vertexStart);
                                    V.get(k).countNeighbors++;
                                }
                                break;
                            }
                        }

                    } else if (c1 == true && c2 == false) {
                        V.add(new Vertex(vertexEnd, vertexStart, costEdges));
                        count++;
                        for (int k = 0; k < count; k++) {
                            if (V.get(k).name == vertexStart) {
                                V.get(k).distance.add(costEdges);
                                V.get(k).neighbors.add(vertexEnd);
                                V.get(k).countNeighbors++;
                                break;
                            }
                        }

                    } else if (c1 == false && c2 == true) {
                        V.add(new Vertex(vertexStart, vertexEnd, costEdges));
                        count++;
                        for (int k = 0; k < count; k++) {
                            if (V.get(k).name == vertexEnd) {
                                V.get(k).distance.add(costEdges);
                                V.get(k).neighbors.add(vertexStart);
                                V.get(k).countNeighbors++;
                                break;
                            }
                        }

                    } else {
                        V.add(new Vertex(vertexStart, vertexEnd, costEdges));
                        V.add(new Vertex(vertexEnd, vertexStart, costEdges));
                        count += 2;
                    }
                    System.out.println(c1 + "   " + c2);
                }

            }

            for (int j = 0; j < count; j++) {
                System.out.println(V.get(j).name + " = " + V.get(j).neighbors + " , " + V.get(j).distance + " ");
            }
            System.out.println();

            DijkstraAlgrorithmResursion DA = new DijkstraAlgrorithmResursion(V);
            int A = 0;
            int js = 0;
            for (int is = 0; is < vertex; is++) {
                for (;js < vertex; js++) {
                    if (is == js) {
                        table[is][js] = 0;
                        A++;
                    } else {
                        int tmp = DA.compute(is, js);
                        table[is][js] = tmp;
                        table[js][is] = tmp;
                        A++;
                        
                    }
                }
                js = is+1;
                System.out.println(A + " / " + vertex * vertex);
            }
            System.out.println(vertex + " " + edges + " " + core);
            /*for (int i = 0; i < vertex; i++) {
                    for (int j = 0; j < vertex; j++) {
                        System.out.print(table[i][j] + " ");
                        //System.out.print(table[i][j]+" ");
                    }
                    System.out.println();
                }*/
            //FileWriter f = new FileWriter(new File("outfile"));
            
            try (PrintWriter out = new PrintWriter("Result.txt")) {
                out.println(vertex + " " + edges + " " + core);
                for (int i = 0; i < vertex; i++) {
                    for (int j = 0; j < vertex; j++) {
                        out.print(table[i][j] + " ");
                        //System.out.print(table[i][j]+" ");
                    }
                    out.println();
                }
                out.close();
            } catch (Exception e) {
                System.out.println(e);
            }

        } else if (mode == 1) { // input distance matrix
            int vertex = scan.nextInt();
            int edges = scan.nextInt();
            int core = scan.nextInt();
            int[][] table = new int[vertex][vertex];

            for (int i = 0; i < vertex; i++) {
                for (int j = 0; j < vertex; j++) {
                    table[i][j] = scan.nextInt();
                }
            }

            /*for (int i = 0 ; i < vertex ; i++){
                for (int j = 0 ; j < vertex ; j++){
                    System.out.print(table[i][j]+" ");
                }
                System.out.println();
            }*/
        } else {
            System.exit(0);
        }
    }
}
