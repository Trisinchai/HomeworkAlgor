import java.util.ArrayList;

public class Vertex {
     int name = -99;
     ArrayList<Integer> neighbors = new ArrayList<>();
     ArrayList<Integer> distance = new ArrayList<>();
     boolean core = false;
     int countNeighbors = 0;

    public Vertex(int name,int neighbors,int distance){
        this.name = name;
        this.neighbors.add(neighbors);
        this.distance.add(distance);
        countNeighbors++;
    }



}
