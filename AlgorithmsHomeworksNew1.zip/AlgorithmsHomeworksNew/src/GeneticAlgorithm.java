import java.util.*;
public class GeneticAlgorithm {
    public static void main(String[] args) {
       double mutationRate = 0.02;
       double crossoverRate = 0.8;
       int lchrom = 50;
       int popsize = 100;
       int maxgen = 100;
       // Random Generator for Integer
       Random rand = new Random((long)24);
       //rand.setSeed((long)25);
       //create new population
       Individual population[]= new Individual[popsize];
       for (int i = 0; i < popsize; i++) 
            population[i] = new Individual(lchrom);
       //fills individual's gene with binary randomly
       for (int i = 0; i < popsize; i++) {
            for (int j = 0; j < lchrom; j++) {
                population[i].gene[j] = (rand.nextDouble() < 0.5) ? 0 : 1;
            }
       }
       for(int gcounter=0; gcounter<maxgen; gcounter++){
             //evaluate each individual
             for (int i = 0; i < popsize; i++) {
                 population[i].fitness = 0;
                 for (int j = 0; j < lchrom; j++) {
                     if (population[i].gene[j] == 1) {
                         population[i].fitness++;
                     }
                 }
             }
            // Print Genome  
            for(int i=0; i < popsize; i++)
                 System.out.println(population[i]);
            // Total Fitness and Average 
            System.out.println("Total fitness " + getTotalFitness(population, popsize));
            System.out.println("Mean fitness " + getMeanFitness(population, popsize));
            // Create new offspring 
            Individual offsprings[] = new Individual[popsize];
            for (int i = 0; i < popsize; i++) 
                 offsprings[i] = new Individual(lchrom);
            // Tournament Selection
            for (int j=0; j < popsize; j++) {
                int champion = rand.nextInt(popsize);
                int contender = rand.nextInt(popsize);
                if (population[champion].fitness<population[contender].fitness) //>
                     champion = contender;
                for (int k=0; k < lchrom; k++)
                     offsprings[j].gene[k]=population[champion].gene[k]; 
            }
            // One-Point Crossover
            for (int i = 0; i < popsize; i = i + 2) {
               if (rand.nextDouble() < crossoverRate) {
                    int splitPoint = rand.nextInt(lchrom);
                    for (int j = splitPoint; j < lchrom; j++) {
                        int temp = offsprings[i].gene[j];
                        offsprings[i].gene[j] = offsprings[i + 1].gene[j];
                        offsprings[i + 1].gene[j] = temp;
                    }
               }
            }
            // One-Point Mutation 
            for (int i = 0; i < popsize; i++) {
               if ( rand.nextDouble() < mutationRate) {
                   int mutationPoint = rand.nextInt(lchrom);
                   if(offsprings[i].gene[mutationPoint] == 1)
                      offsprings[i].gene[mutationPoint] = 0;
                   else
                      offsprings[i].gene[mutationPoint] = 1;
               }
            }
            // Copy offspring to the next generation   
            for (int i = 0; i < popsize; i++) {
               for( int j = 0; j < lchrom; j++) {
                      population[i].gene[j]=offsprings[i].gene[j]; 
               }
            }
        }
       // End of Main Loop 
    }
    // End of Main Method 
    public static int getTotalFitness(Individual pop[], int popsize) {
        int totalFitness = 0;
        for (int i = 0; i < popsize; i++) {
            totalFitness = totalFitness + pop[i].fitness;
        }
        return totalFitness;
    }
    public static double getMeanFitness(Individual pop[], int popsize) {
        double meanFitness = getTotalFitness(pop, popsize) / (double) popsize;
        return meanFitness;
    }
}